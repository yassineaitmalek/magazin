package com.Entities;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpSpringDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
