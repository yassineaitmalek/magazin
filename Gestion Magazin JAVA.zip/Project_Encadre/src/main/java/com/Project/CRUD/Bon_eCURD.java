package com.Project.CRUD;

import org.springframework.data.repository.CrudRepository;

import com.Project.Entities.Bon_e;

public interface Bon_eCURD  extends CrudRepository<Bon_e, Long>{

}
