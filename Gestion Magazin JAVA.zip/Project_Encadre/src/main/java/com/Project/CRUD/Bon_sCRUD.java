package com.Project.CRUD;

import org.springframework.data.repository.CrudRepository;

import com.Project.Entities.Bon_s;

public interface Bon_sCRUD  extends CrudRepository<Bon_s,Long>{

}
